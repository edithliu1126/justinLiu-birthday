
import React, { useState, useEffect } from 'react';
import { generateBlessing, generateVoiceBlessing, playPCM } from './services/geminiService';
import { BlessingStyle } from './types';
import Confetti from './components/Confetti';

const App: React.FC = () => {
  const [currentBlessing, setCurrentBlessing] = useState<string>("点击下方的按钮，接收我们的爱意吧！");
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [showCake, setShowCake] = useState<boolean>(false);
  const [candlesLit, setCandlesLit] = useState<boolean>(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [isWeChat, setIsWeChat] = useState<boolean>(false);
  const [copySuccess, setCopySuccess] = useState<boolean>(false);

  useEffect(() => {
    const ua = navigator.userAgent.toLowerCase();
    setIsWeChat(ua.includes('micromessenger'));
  }, []);

  const handleBlessingClick = async (style: BlessingStyle) => {
    setIsGenerating(true);
    const blessing = await generateBlessing(style);
    setCurrentBlessing(blessing);
    setIsGenerating(false);
  };

  const handleVoicePlay = async () => {
    if (isPlayingAudio) return;
    setIsPlayingAudio(true);
    const audioData = await generateVoiceBlessing(currentBlessing);
    if (audioData) {
      await playPCM(audioData);
    }
    setIsPlayingAudio(false);
  };

  const toggleCake = () => setShowCake(!showCake);
  const lightCandles = () => {
    setCandlesLit(true);
    // Add small feedback or sound here if desired
  };

  const copyToClipboard = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(() => {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    });
  };

  return (
    <div className="min-h-screen relative flex flex-col items-center pb-20 overflow-hidden bg-[#fffafa]">
      <Confetti />

      {/* WeChat Guide Overlay */}
      {isWeChat && (
        <div className="fixed inset-0 z-[100] wechat-overlay flex flex-col items-end p-6 text-white pointer-events-auto">
          <div className="animate-bounce mb-2">
            <i className="fas fa-long-arrow-alt-up text-5xl"></i>
          </div>
          <p className="text-xl font-bold mb-4 text-right">
            点击右上角选择“在浏览器中打开”<br/>
            以获得最佳互动体验
          </p>
          <button 
            onClick={() => setIsWeChat(false)}
            className="mt-4 px-6 py-2 border-2 border-white rounded-full hover:bg-white hover:text-black transition-all"
          >
            知道了
          </button>
        </div>
      )}

      {/* Hero Section */}
      <div className="w-full max-w-4xl bg-white shadow-2xl rounded-b-[3rem] overflow-hidden z-10 border-b-8 border-red-100">
        <div className="relative">
          <img 
            src="https://picsum.photos/1200/600" 
            alt="Justin Liu Birthday" 
            className="w-full h-64 md:h-96 object-cover brightness-90"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
          <div className="absolute bottom-6 left-0 right-0 text-center text-white">
            <h1 className="text-5xl md:text-7xl font-bold mb-2 tracking-tighter drop-shadow-lg">
              Justin Liu
            </h1>
            <p className="text-xl md:text-3xl chinese-font tracking-widest drop-shadow-md">
              祝最亲爱的爸爸生日快乐！
            </p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="w-full max-w-3xl px-4 mt-10 z-10 flex flex-col gap-8">
        
        {/* Interactive Blessing Card */}
        <section className="bg-white rounded-[2.5rem] p-8 shadow-2xl border-2 border-pink-50 text-center relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-2 h-full bg-gradient-to-b from-red-400 to-pink-500"></div>
          
          <div className="mb-8 relative">
            <span className="absolute -top-4 -left-2 text-pink-200 text-7xl opacity-50"><i className="fas fa-quote-left"></i></span>
            <p className={`text-2xl md:text-3xl text-gray-800 font-medium leading-relaxed min-h-[120px] px-4 flex items-center justify-center transition-all duration-500 ${isGenerating ? 'scale-95 opacity-30' : 'scale-100 opacity-100'}`}>
              {currentBlessing}
            </p>
            <span className="absolute -bottom-6 -right-2 text-pink-200 text-7xl opacity-50"><i className="fas fa-quote-right"></i></span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-10">
            {[
              { style: BlessingStyle.WHEE, color: 'bg-red-400', icon: 'fa-laugh-beam' },
              { style: BlessingStyle.WARM, color: 'bg-orange-400', icon: 'fa-heart' },
              { style: BlessingStyle.ADORE, color: 'bg-rose-500', icon: 'fa-star' },
              { style: BlessingStyle.POETIC, color: 'bg-teal-500', icon: 'fa-feather' }
            ].map((item) => (
              <button
                key={item.style}
                onClick={() => handleBlessingClick(item.style)}
                disabled={isGenerating}
                className={`group/btn py-4 px-2 rounded-2xl font-bold text-white shadow-lg transform transition-all hover:scale-105 active:scale-95 disabled:opacity-50 disabled:grayscale ${item.color} flex flex-col items-center gap-2`}
              >
                <i className={`fas ${item.icon} text-xl group-hover/btn:rotate-12 transition-transform`}></i>
                <span className="text-sm">{item.style}</span>
              </button>
            ))}
          </div>

          <button 
            onClick={handleVoicePlay}
            disabled={isPlayingAudio || isGenerating}
            className="mt-10 inline-flex items-center gap-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white px-10 py-4 rounded-full hover:shadow-indigo-200 hover:shadow-2xl transition-all disabled:from-gray-300 disabled:to-gray-400 font-bold tracking-wider"
          >
            {isPlayingAudio ? (
              <><i className="fas fa-circle-notch fa-spin"></i> 正在深情朗读...</>
            ) : (
              <><i className="fas fa-play-circle text-xl"></i> 开启童声朗读</>
            )}
          </button>
        </section>

        {/* Surprise Section */}
        <section className="text-center py-6">
          <div className="inline-block relative">
            <div className="absolute -inset-4 bg-pink-100 rounded-full blur-xl opacity-40 animate-pulse"></div>
            <button 
              onClick={toggleCake}
              className="relative bg-white p-8 rounded-full shadow-2xl float-animation border-4 border-pink-100 group transition-all hover:rotate-6 active:scale-90"
            >
              <i className={`fas fa-birthday-cake text-7xl text-pink-500 group-hover:scale-110 transition-transform ${showCake ? 'text-orange-400' : ''}`}></i>
            </button>
            <div className="mt-6 text-gray-500 font-bold text-lg tracking-widest">点击揭晓小惊喜</div>
          </div>

          {showCake && (
            <div className="mt-10 p-10 bg-white rounded-[3rem] shadow-2xl border-4 border-dashed border-pink-100 animate-bounce-in relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4"><i className="fas fa-certificate text-yellow-300 text-4xl opacity-20 rotate-12"></i></div>
              <div className="relative inline-block">
                <div className="text-9xl mb-6 select-none">🎂</div>
                {candlesLit ? (
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 -mt-8 flex gap-3">
                    <span className="animate-pulse text-4xl">🔥</span>
                    <span className="animate-pulse text-4xl delay-75">🔥</span>
                    <span className="animate-pulse text-4xl delay-150">🔥</span>
                  </div>
                ) : (
                  <button 
                    onClick={lightCandles}
                    className="absolute top-0 left-1/2 -translate-x-1/2 -mt-10 bg-gradient-to-b from-yellow-300 to-orange-500 text-sm font-black px-6 py-2 rounded-full text-white hover:scale-110 transition-all shadow-xl whitespace-nowrap"
                  >
                    ✨ 点燃生日愿望 ✨
                  </button>
                )}
              </div>
              <h3 className="text-3xl font-black text-gray-800 mt-6 tracking-tight">
                {candlesLit ? "愿您的所有愿望都成真！" : "最帅的 Justin Liu，快来许愿吧！"}
              </h3>
              <p className="mt-4 text-gray-500 chinese-font text-xl italic opacity-80">
                岁月温柔，因为有您的陪伴
              </p>
            </div>
          )}
        </section>

        {/* Share & Copy Section */}
        <div className="flex flex-col items-center gap-4 mt-8">
          <button 
            onClick={copyToClipboard}
            className={`flex items-center gap-2 px-8 py-3 rounded-2xl transition-all font-bold ${copySuccess ? 'bg-green-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
          >
            <i className={`fas ${copySuccess ? 'fa-check-circle' : 'fa-link'}`}></i>
            {copySuccess ? '链接已复制！' : '复制网址发送给爸爸'}
          </button>
          <p className="text-xs text-gray-400 flex items-center gap-2">
            <i className="fab fa-weixin text-green-500"></i>
            微信内可直接点击右上角分享本页面
          </p>
        </div>

        {/* Footer Info */}
        <footer className="mt-16 text-center text-gray-400 pb-16">
          <div className="flex justify-center gap-6 text-2xl text-pink-200 mb-6">
            <i className="fas fa-heart animate-pulse"></i>
            <i className="fas fa-star spin-slow"></i>
            <i className="fas fa-gift animate-bounce"></i>
          </div>
          <p className="text-sm font-medium tracking-widest uppercase opacity-60">
            Dedicated with love to Justin Liu
          </p>
          <p className="text-xs mt-2 opacity-40">2025 Family Birthday Portal</p>
        </footer>
      </main>

      {/* Floating Action Buttons */}
      <div className="fixed bottom-6 right-6 flex flex-col gap-4 z-40 hidden md:flex">
        <button 
          onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}
          className="w-12 h-12 bg-white rounded-full shadow-xl flex items-center justify-center text-gray-400 hover:text-pink-500 transition-colors"
        >
          <i className="fas fa-chevron-up"></i>
        </button>
      </div>

      {/* Sticky Mobile Navbar - Re-styled for better feel */}
      <div className="fixed bottom-0 left-0 right-0 glass-morphism p-4 flex justify-around items-center md:hidden z-50 border-t border-white/50">
        <button onClick={copyToClipboard} className="flex flex-col items-center gap-1 text-pink-500 active:scale-90 transition-transform">
          <i className="fas fa-paper-plane text-2xl"></i>
          <span className="text-[10px] font-bold">送出祝福</span>
        </button>
        <div className="w-14 h-14 bg-gradient-to-tr from-pink-400 to-red-500 rounded-full flex items-center justify-center -mt-10 shadow-xl border-4 border-white text-white active:scale-95 transition-transform" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
          <i className="fas fa-home text-xl"></i>
        </div>
        <button onClick={() => alert("再次点击心形按钮或蛋糕揭晓更多惊喜吧！")} className="flex flex-col items-center gap-1 text-gray-400">
          <i className="fas fa-smile-wink text-2xl"></i>
          <span className="text-[10px] font-bold">查看玩法</span>
        </button>
      </div>
    </div>
  );
};

export default App;
