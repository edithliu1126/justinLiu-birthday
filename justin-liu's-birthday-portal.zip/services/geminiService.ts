
import { GoogleGenAI, Modality } from "@google/genai";
import { BlessingStyle } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateBlessing(style: BlessingStyle, name: string = "Justin Liu"): Promise<string> {
  const prompt = `为一位名叫 ${name} 的父亲写一段简短的生日祝福。
  风格要求：${style}。
  对象：孩子们对爸爸说。
  字数：50字以内。
  语言：中文（除了名字 ${name} 以外）。
  不要包含任何“希望这能让你惊喜”之类的话。`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "祝 Justin Liu 永远年轻，生日快乐！";
  } catch (error) {
    console.error("Error generating blessing:", error);
    return "祝爸爸生日快乐，身体健康！";
  }
}

export async function generateVoiceBlessing(text: string): Promise<string | undefined> {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `用温柔可爱的童声朗读：${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  } catch (error) {
    console.error("Error generating TTS:", error);
    return undefined;
  }
}

// Helper to decode and play PCM audio
export async function playPCM(base64: string) {
  const decode = (b64: string) => {
    const binaryString = atob(b64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const decodeAudioData = async (
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
  const audioBuffer = await decodeAudioData(decode(base64), audioContext, 24000, 1);
  const source = audioContext.createBufferSource();
  source.buffer = audioBuffer;
  source.connect(audioContext.destination);
  source.start();
}
