
export enum BlessingStyle {
  WHEE = '幽默风',
  WARM = '温馨风',
  ADORE = '崇拜风',
  POETIC = '诗意风'
}

export interface Blessing {
  text: string;
  style: BlessingStyle;
}
